var $ROOT_DIRECTORY = "./";
var $DESKTOP = false;